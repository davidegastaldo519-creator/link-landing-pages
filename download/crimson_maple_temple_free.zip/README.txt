CRIMSON MAPLE - ARENA "TEMPLE"  (campione gratuito)
NewHorizon Builds - https://mappe.newhorizonsmp.it
====================================================================

--------------------------------------------------------------------
ITALIANO
--------------------------------------------------------------------
Cosa c'e' in questo pacchetto
  crimson_maple_courtyard_temple.schem   l'arena completa
  coordinates.json                       spawn, limiti e livello del vuoto
  LICENSE.txt                            cosa puoi farci
  NEWHORIZON_BUILDS.txt                  gli altri pacchetti

L'arena in due righe
  Tipo:        cortile, tema tempio
  Dimensioni:  81 x 52 x 85 blocchi  (84.251 blocchi piazzati)
  Pavimento:   piatto, adatto a tutti i kit PvP
  Kit testati: NoDebuff, Debuff, Boxing, Combo, Classic, Sword, Axe,
               Archer, Soup, Gapple

Come si incolla (WorldEdit o FastAsyncWorldEdit)
  1. Metti il file in:  plugins/WorldEdit/schematics/
     (con FAWE:         plugins/FastAsyncWorldEdit/schematics/)
  2. In gioco:          //schem load crimson_maple_courtyard_temple
  3. Mettiti dove vuoi il CENTRO dell'arena, poi:   //paste
     La schematica e' centrata: il punto in cui stai diventa 0,0,0.

Coordinate per il setup del plugin (relative al centro)
  Spawn A:   -15.5 , 0 , 0.5    con yaw -90
  Spawn B:    16.5 , 0 , 0.5    con yaw  90
  Costruzione consentita:  da Y+0 a Y+5
  Y del vuoto (morte):     -31

  In pratica: se incolli il centro a 100 / 64 / 200, lo spawn A va a
  84.5 / 64 / 200.5 e il vuoto si imposta a 33.

Versioni
  Fatta per Minecraft 1.21. Funziona dalla 1.20.3 in su.

Problemi?
  newhorizonmine@gmail.com  -  oppure Discord: https://discord.gg/GVEZQ69FXF
  Ti risponde una persona vera, in italiano o inglese.

--------------------------------------------------------------------
ENGLISH
--------------------------------------------------------------------
What's inside
  crimson_maple_courtyard_temple.schem   the full arena
  coordinates.json                       spawns, build limits, void level
  LICENSE.txt                            what you can do with it
  NEWHORIZON_BUILDS.txt                  the other packs

The arena at a glance
  Type:        courtyard, temple theme
  Size:        81 x 52 x 85 blocks  (84,251 blocks placed)
  Floor:       flat, works with every PvP kit
  Kits tested: NoDebuff, Debuff, Boxing, Combo, Classic, Sword, Axe,
               Archer, Soup, Gapple

How to paste it (WorldEdit or FastAsyncWorldEdit)
  1. Drop the file into:  plugins/WorldEdit/schematics/
     (with FAWE:          plugins/FastAsyncWorldEdit/schematics/)
  2. In game:             //schem load crimson_maple_courtyard_temple
  3. Stand where you want the arena CENTRE, then:   //paste
     The schematic is centred: where you stand becomes 0,0,0.

Setup coordinates for your plugin (relative to the centre)
  Spawn A:   -15.5 , 0 , 0.5    yaw -90
  Spawn B:    16.5 , 0 , 0.5    yaw  90
  Build limits:   Y+0 to Y+5
  Void (death) Y: -31

  Example: paste the centre at 100 / 64 / 200 and spawn A lands at
  84.5 / 64 / 200.5, with the void Y set to 33.

Versions
  Built for Minecraft 1.21. Works on 1.20.3 and newer.

Need help?
  newhorizonmine@gmail.com  -  or Discord: https://discord.gg/GVEZQ69FXF
  A real person from our team answers, in English or Italian.
