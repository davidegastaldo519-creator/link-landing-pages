NEWHORIZON MC - FREE SUMO ARENA (Lotus)

A free sample from the Crimson Maple Duels pack (lobby + 20 arenas).
Full packs: https://mappe.newhorizonsmp.it  (also on https://newhorizonmc.itch.io)

HOW TO PASTE
1. Install WorldEdit or FastAsyncWorldEdit on your server (Minecraft Java 1.20.3+).
2. Put the .schem file in plugins/WorldEdit/schematics (or plugins/FastAsyncWorldEdit/schematics).
3. In game: //schem load crimson_maple_sumo_lotus
4. Stand where you want the centre of the arena and type: //paste

Free to use on your server. Please do not re-upload or resell it.
Designed in Italy by NewHorizon MC. Made with the help of AI tools, checked block by block.
Not an official Minecraft product. Not approved by or associated with Mojang or Microsoft.
